using DiApi.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddScoped<IDbRepo, NoSqlDbRepo>();

var app = builder.Build();

app.UseHttpsRedirection();


app.MapGet("/getdata", (IDbRepo repo) =>
{
    // var repo = new NoSqlDbRepository();
    return Results.Ok($"--> Data From Repository is {repo.ReturnData()}");
});


app.Run();

