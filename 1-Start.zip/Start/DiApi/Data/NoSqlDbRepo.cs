namespace DiApi.Data
{
    public class NoSqlDbRepo : IDbRepo
    {
        public string ReturnData()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("--> Getting Data from the No SQL Repository");
            Console.ResetColor();
            return("No SQL Data from the Repository");
        }

    }
}