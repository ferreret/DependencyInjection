namespace DiApi.DataServices
{
    public class HttpDataService : IDataService
    {
        public string GetOrderApiData(string url)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("---> Getting ORDER data...");
            Console.ResetColor();
            return "Some ORDER data via API";
        }

        public string GetProductApiData(string url)
        {
            return "Some PRODUCT data via API";
        }
    }
}