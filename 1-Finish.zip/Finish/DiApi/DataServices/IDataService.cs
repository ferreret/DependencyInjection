namespace DiApi.DataServices
{
    public interface IDataService
    {
        public string GetProductApiData(string url);
        public string GetOrderApiData(string url);
        
    }
}