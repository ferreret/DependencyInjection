using DiApi.DataServices;

namespace DiApi.Data
{
    public class NoSqlDbRepo : IDbRepo
    {
        private readonly IDataService _dataService;

        public NoSqlDbRepo(IDataService dataService)
        {
            _dataService = dataService;
        }

        public string ReturnData()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("--> Getting Data from the No SQL Repository");
            Console.ResetColor();

            _dataService.GetOrderApiData("http://something.com");
            return("No SQL Data from the Repository");
        }

    }
}