namespace DiApi.Data
{
    public interface IDbRepo
    {
        public string ReturnData();
    }
}