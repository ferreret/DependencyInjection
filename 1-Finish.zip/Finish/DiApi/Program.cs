using DiApi.Data;
using DiApi.DataServices;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddScoped<IDbRepo, NoSqlDbRepo>();
builder.Services.AddScoped<IDataService, HttpDataService>();

//https://docs.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.builder.webapplicationbuilder.build?view=aspnetcore-6.0#microsoft-aspnetcore-builder-webapplicationbuilder-build
var app = builder.Build();

app.UseHttpsRedirection();


app.MapGet("/getdata", (IDbRepo repo) =>
{
    // var repo = new NoSqlDbRepository();
    return Results.Ok($"--> Data From Repository is {repo.ReturnData()}");
});


app.Run();

