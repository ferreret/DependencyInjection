namespace DiApi.Data
{
    public class SqlDbRepo : IDbRepo
    {
    
        public string ReturnData()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("--> Getting Data from the SQL Repository");
            Console.ResetColor();
            return("SQL Data from the Repository");
        }
    }
}